//package rmit;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
///**
// * Created by CoT on 10/12/17.
// */
//
//@Configuration
//public class AppConfig {
//    @Bean
//    public HelloManager hello() {
//        return new HelloManager();
//    }
//
//    @Bean
//    public ByeManager bye() {
//        return new ByeManager();
//    }
//
//    @Bean
//    public Communicator communicator() {
//        return new Communicator();
//    }
//
//    @Bean
//    public MathService mathService() {
//        return new MathService();
//    }
//
//    @Bean AddService addService() {
//        return new AddService();
//    }
//
//    @Bean MinusService minusService() {
//        return new MinusService();
//    }
//}
