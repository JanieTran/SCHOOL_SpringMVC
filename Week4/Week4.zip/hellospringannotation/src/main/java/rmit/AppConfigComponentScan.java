package rmit;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan("rmit")
public class AppConfigComponentScan {

}
