package tut4exercises;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan("tut4exercises")
public class AppConfig {

}
