# hellospringannotacion

Hello all 

In this project you will learn how to use Spring Annotation to define Spring bean.

You also learn how to create bean using Annotation.
