package rmit;

public class Goodbye {
    public void bye() {
        System.out.println("Goodbye");
    }
}
