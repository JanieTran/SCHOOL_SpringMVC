package rmit;

/**
 * Created by CoT on 10/12/17.
 */
public class EmployeeService {

    public String getEmployees(){
        return "Employee List";
    }
}
