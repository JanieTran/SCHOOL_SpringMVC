EEET2580 - Enterprise Application Development
Name: Tran Thi Hong Phuong
ID: s3623386
Date: 15th July, 2018

-Link to website-
ec2-34-216-115-188.us-west-2.compute.amazonaws.com